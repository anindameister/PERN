import json

# Opening JSON file
json_file = open('jsoning.json', )
loaded_json_file = json.load(json_file)

# checking the keys of the loaded json file
list_keys = list(loaded_json_file.keys())

# checking the values of the loaded json file
list_values = list(loaded_json_file.values())

# finding the keys of the values of the loaded json file
list_keys_of_values = list(list_values[1].keys())

# finding the values of the values of the loaded json file
list_values_of_values = list(list_values[1].values())


# this functions takes a list containing strings and checks if they are separated by dots, and returns a cleaned string
def required_function(listing):
    for i in range(0, len(listing)):
        try:
            list_of_list_elements = listing[i].split(".")
            empty_string = ""
            for ele in list_of_list_elements:
                empty_string += ele
            listing[i] = empty_string

        except AttributeError:
            pass

    return listing


required_function(list_values_of_values)


# this functions takes a list containing strings and checks if they have un-necessary quotes, and returns a cleaned string
def removes_quotes(listing):
    for i in range(0, len(listing)):

        stringing = listing[i]
        try:

            if stringing.startswith('"') and stringing.endswith('"'):
                listing[i] = stringing[1:-1]

        except AttributeError:
            pass
    return listing


removes_quotes(list_values_of_values)

# merging cleaned values with corresponding keys and creating many dictionaries with a list
list_of_dicts = []
for i in range(0, len(list_keys_of_values)):
    dict = {list_keys_of_values[i]: list_values_of_values[i]}
    list_of_dicts.append(dict)

# merging all the dictionaries into one
merged_dict = {}
for dictionary in list_of_dicts:
    for k, v in dictionary.items():
        merged_dict[k] = v

# creating the final dictionary
final_dict = {list_keys[0]: list_values[0], list_keys[1]: merged_dict}

# removing "out-of-service": null
del final_dict["properties"]['out-of-service']

# creating the json file
with open("output_json.json", "w") as outfile:
    json.dump(final_dict, outfile)
