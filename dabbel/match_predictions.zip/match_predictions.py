import pandas as pd
import datetime
import time
import csv

# number of sensors can be specified here
num_sensors = 4

# actual values
df_actual = pd.read_csv('1.csv')


# datetime to timestamp format for ease of comparison of times
def convert_to_timestamp(date_time):
    timestamp = datetime.datetime.strptime(date_time, '%m/%d/%Y %H:%M').timestamp()
    return timestamp


# convert first dataframe(actual values) to timestamp
for index, row in df_actual.iterrows():
    df_actual["Time"][index] = convert_to_timestamp(row["Time"])

# prediction values
df_pred = pd.read_csv('2.csv')

# convert first dataframe(prediction values) to timestamp
for index, row in df_pred.iterrows():
    df_pred["Time"][index] = convert_to_timestamp(row["Time"])

# dictionary of sensor values already used, according to
pred_already_used = {k: [] for k in list(range(1, num_sensors + 1))}


# find nearest timestamp in prediction dataframe
def find_nearest_time(current_time):
    time_to_find_table_2 = list(df_pred['Time'])
    differences = []

    for i in range(0, len(time_to_find_table_2)):
        time_diff = abs(time_to_find_table_2[i] - current_time)
        differences.append(time_diff)
    nearest_index = differences.index(min(differences))
    return nearest_index


time1 = time.time()
output = []
for index, row in df_actual.iterrows(): #iterating over the table 1 which contains actual data
    for sensor_id in range(1, num_sensors + 1): 
        sensor_column_name = f'Sensor{sensor_id}'
        row_to_check = find_nearest_time(row['Time']) #calling the function in here, to find the closest time
        pred_value = df_pred[sensor_column_name][row_to_check] #working on the second table which contains the predicted values
        if row_to_check == 0 and pred_value.lower() == 'null': #this way we are not checking for row index=0
            continue
        find_value_flag = False
        continue_flag = False
        while not find_value_flag:
            if pred_value.lower() == 'null':
                row_to_check -= 1 #checking the value one row above from the second table 
                if row_to_check < 0:
                    continue_flag = True
                    break
                elif row_to_check in pred_already_used[sensor_id]: 
                    row_to_check -= 1 #if the value on the one row above has been utilised then checking one more step above
                    if row_to_check < 0:
                        continue_flag = True
                        break
                pred_value = df_pred[sensor_column_name][row_to_check]
            else:
                find_value_flag = True
        if continue_flag:
            continue
        pred_already_used[sensor_id].append(row_to_check)
        print(datetime.datetime.fromtimestamp(row['Time']), sensor_column_name, row[sensor_column_name], pred_value)
        output.append(
            [datetime.datetime.fromtimestamp(row['Time']), sensor_column_name, row[sensor_column_name], pred_value])
time2 = time.time()

print(f'Time taken : {time2 - time1}')
headings = ['Time', 'Sensor', 'Temperature', 'Prediction']
with open("output.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(headings)
    writer.writerows(output)
